// GPS coordinate system Project AT PSUT , source code , 4/1/2015
//Done By team members Moahmmed khalifa , Ola Frahti and saja jaber
//if you are reading this ,You  have to know that the code got sum problems
// and bugs with logec steps to do our function well
//BUT the functions in the code itts 100% well functianly


//WE have to wait for -1-Sec AT least after sending the AT command through the UART
//then followed by (13) which is return in assci
// If the GPS hadnt send the Right massage it will send again until the Right data is sent


char Timer=0,Right=0;
char My[70],Counter=0;

//SIM init,
char AT[]= "AT!" ;                             //STARTing  COmmands,
char ATE[]= "ATE0!";                         //Disable ECHO
char Lang[]="X=";
char Lat[]=" Y=";
//SMS Commands,
char CMGF[]= "AT+CMGF=1!";                   //TXT MASSAGE,
char CMGR[]= "AT+CMGR=1!";                   //Read Message
char CMGS[]= "AT+CMGS=\"0798776554\"!";     //SEND MASSAGE,
char CMGDA[]= "AT+CMGD=4!";

//GPS commands,
char PWR[]="AT+CGPSPWR=1!";   // GPS power is on
char RST[]="AT+CGPSRST=1!";   //Reset the GPS is on
char INF[]="AT+CGPSINF=0!";   // get the GPS Locatoin

void Send_Tx_Char(char);
void Send_Tx_Text(char Text[]);
void init_SIM(void);

//void Send_SMS(void);

void interrupt(void){
if(INTCON & 0x04){
Timer ++;
if(Timer > 40)
Timer = 0;
INTCON = INTCON & 0xFB;
}
if( PIR1 & 0x20){
PIR1 = 0x00;
My[Counter] = RCREG;
if(RCREG == '+' || RCREG == 43)
         Right = 1;
else
         Right = 0;
Counter++;
if(Counter > 89)
Counter = 0 ;
RCSTA = RCSTA & 0xF9;
}
}

void main() {
int i=0,x=0;
Counter=0;
PORTC = 0x80;
RCSTA = 0X90;     //Serial Port Enable bit, Receive Enable bit
TXSTA = 0X22;  //Transmit Enable bit
SPBRG = 12;   // boud rate
INTCON = 0XE0; //GIE , PIE
PIR1 = 0X00;   // clear flag
init_SIM();
PIE1 = 0X20;
Right = 0;
Counter=0;
option_reg=0x87;
while(1){

Send_Tx_Text(CMGR);
Timer=0;
while(Timer>32);

if (Right){
Counter=0;

Send_Tx_Text(INF);
Timer=0;
while(Timer>32);

PIE1 = 0x00; //Turn off recive
Right=0;
//Send_SMS

Send_Tx_Text(CMGF);
Timer=0;
while(Timer>32);
Send_Tx_Text(CMGS);
Timer=0;
while(Timer>32);
Send_Tx_Text(lang);
for (i=0;i<11;i++)
Send_Tx_char(My[i]);
Send_Tx_Text(lat);
for (i=12;i<23;i++)
Send_Tx_char(My[i]);


Send_Tx_char(26);

Timer=0;
while(Timer>32);
Send_Tx_char(13);
Timer=0;
while(Timer>32);
Send_Tx_Text(CMGDA);
Timer=0;
while(Timer>32);
PIE1 = PIE1 | 0x20;
}

}

}




void Send_Tx_Char(char send){
while(!(TXSTA & 0x02));
TXREG = send ;
}

void Send_Tx_Text(char Text[]){
int cnt = 0;
while(Text[cnt] != '!'){
Send_Tx_Char(Text[cnt]);
cnt++;
}
Send_Tx_Char(13);
}

void init_SIM(void){
Send_Tx_Text(ATE);
Timer=0;
while(Timer>32);

Send_Tx_Text(PWR);
Timer=0;
while(Timer>32);

Send_Tx_Text(RST);
Timer=0;
while(Timer>32);

}